intern.c -> To calculate Flops
iops.c -> To calculate Iops
make all -> To make all binaries
./script -> To run all required binary to generate the result
result.txt -> Result of running script on mamba
